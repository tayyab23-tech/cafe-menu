// This function runs when the Order button is clicked.
function order() {
    alert("Thank you for choosing Chai Corner! Online ordering will be available soon.");
}
